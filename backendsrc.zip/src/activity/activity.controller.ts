import { Controller, Post, Body } from '@nestjs/common';
import { ActivityService } from './activity.service';

@Controller('activity')
export class ActivityController {
  constructor(private activityService: ActivityService) {}

  @Post()
  log(@Body() body: { userId: number; activity: string }) {
    return this.activityService.logActivity(body.userId, body.activity);
  }
}
