import { Injectable } from '@nestjs/common';
import { db } from '../drizzle/drizzle.config';
import { activity } from '../drizzle/schema';

@Injectable()
export class ActivityService {
  async logActivity(userId: number, activityText: string) {
    await db.insert(activity).values({
      userId,
      activity: activityText,
      doneAt: new Date(),
    });
  }
}
