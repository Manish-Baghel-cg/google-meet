/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { ActivityModule } from './activity/activity.module';
import { DrizzleModule } from './drizzle/drizzle.config';

@Module({
  imports: [
    DrizzleModule, 
    AuthModule, 
    UsersModule, 
    ActivityModule
  ],
})
export class AppModule {}
