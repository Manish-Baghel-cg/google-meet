export class SignupDto {
  name: string;
  email: string;
  password: string;
}
