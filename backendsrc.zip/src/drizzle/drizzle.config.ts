import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://localhost:password@localhost:5432/camelq_connect',
});

export const db = drizzle(pool, { schema });
export const DrizzleModule = {
  module: class DrizzleModule {},
  providers: [{ provide: 'DATABASE', useValue: db }],
  exports: ['DATABASE'],
};
