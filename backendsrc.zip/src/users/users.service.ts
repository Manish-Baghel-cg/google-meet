import { Injectable } from '@nestjs/common';
import { db } from '../drizzle/drizzle.config';
import { users } from '../drizzle/schema';
import { eq } from 'drizzle-orm';
import * as bcrypt from 'bcrypt';
import { SignupDto } from '../auth/dto/signup.dto';

@Injectable()
export class UsersService {
  async createUser(dto: SignupDto) {
    const hashedPassword = await bcrypt.hash(dto.password, 10);
    const [user] = await db.insert(users).values({
      name: dto.name,
      email: dto.email,
      password: hashedPassword,
    }).returning();
    return user;
  }

  async findByEmail(email: string) {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
}
