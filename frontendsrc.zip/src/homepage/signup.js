import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import useStyles from './styles';
import { Button, Grid, Link, TextField, Typography } from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';

const Signup = () => {
  const classes = useStyles();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cpassword, setCPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [nameError, setNameError] = useState('');
  const history = useHistory();

  const handleSignup = async (e) => {
    e.preventDefault();

    setNameError('');
    setEmailError('');
    setPasswordError('');

    if (name.trim() === '') {
      setNameError('Name is required');
      return;
    }

    if (password !== cpassword) {
      setPasswordError('Passwords do not match');
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (data.message?.includes('email')) {
          setEmailError(data.message);
        } else {
          setPasswordError(data.message || 'Signup failed');
        }
        return;
      }

      // Save token (optional: could be in localStorage or context)
      localStorage.setItem('token', data.access_token);

      history.push('/teams');
    } catch (err) {
      console.error('Signup error:', err);
      setEmailError('Something went wrong. Please try again later.');
    }
  };

  return (
    <main>
      <Grid
        container
        style={{ background: 'linear-gradient(to right bottom, #eee7cc, #dbe3e9)' }}
      >
        <Grid item className={classes.signup}>
          <img
            className={classes.bigLogo}
            src={process.env.PUBLIC_URL + 'images/teams.png'}
            alt="ms_logo"
          />
          <Typography
            variant="h5"
            align="left"
            color="textPrimary"
            fontWeight="bold"
            gutterBottom
          >
            Sign up
          </Typography>

          <form onSubmit={handleSignup}>
            {nameError && <Alert severity="error">{nameError}</Alert>}
            {emailError && <Alert severity="error">{emailError}</Alert>}
            {passwordError && <Alert severity="error">{passwordError}</Alert>}

            <TextField
              className={classes.textField}
              variant="outlined"
              color="primary"
              label="Name"
              onChange={(e) => setName(e.target.value)}
              error={!!nameError}
            />
            <TextField
              className={classes.textField}
              variant="outlined"
              color="primary"
              label="E-mail id"
              type="email"
              onChange={(e) => setEmail(e.target.value)}
              error={!!emailError}
            />
            <TextField
              className={classes.textField}
              variant="outlined"
              color="primary"
              label="Create Password"
              type="password"
              onChange={(e) => setPassword(e.target.value)}
              error={!!passwordError}
            />
            <TextField
              className={classes.textField}
              variant="outlined"
              color="primary"
              label="Confirm Password"
              type="password"
              onChange={(e) => setCPassword(e.target.value)}
            />

            <Button
              className={classes.buttonSignup}
              color="primary"
              type="submit"
              variant="contained"
              fullWidth
            >
              Sign up
            </Button>
          </form>

          <p>
            <Typography variant="body2" color="textPrimary" gutterBottom>
              Already a user?
              <Link href="/signin"> Sign in </Link>
              instead
            </Typography>
          </p>
        </Grid>
      </Grid>
    </main>
  );
};

export default Signup;
